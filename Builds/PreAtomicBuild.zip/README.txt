Extract Everything for Dino to work properly
