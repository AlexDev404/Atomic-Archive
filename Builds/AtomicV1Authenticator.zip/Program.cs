﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Atomic_Auth;
using System;
using System.IO;
using DocumentFormat;

class SynchronousSocketListener
{

    class ACSharp
    {
        bool bClosed;

        static void Main(string[] args)
        {
            Console.Title = Settings.ConsoleTitle;
            ACSharp main = new ACSharp();
            main.ServerStart();
            

        }

        TcpListener server = new TcpListener(IPAddress.Parse(Settings.ip), Settings.port);
        private void ServerStart()
        {
            int IsReadable = 1;
            int Mode = Settings.Mode;
            Console.WriteLine("Welcome to ACSharp, ACSharp is a Atomic Authenticator to keep skids from using our sources.");
            Console.WriteLine("Accepting Connections from " + Settings.ip + ":" + Settings.port, Environment.NewLine);
            if (Mode == 1)
            {
                Console.WriteLine("Currently in: Log Mode (Only transmits output information in Logs)");
            }
            if (Mode == 2)
            {
                Console.WriteLine("Currently in: Console Mode (Only transmits output information in Console)");
            }
            server.Start();

            Console.WriteLine("Welcome to ACSharp, ACSharp is a Atomic Authenticator to keep skids from using our sources.");
            Console.WriteLine("Accepting Connections from " + Settings.ip + ":" + Settings.port, Environment.NewLine);
            Console.WriteLine("Commands:");
            Console.WriteLine("Stop = Stops Accepting Connections");
            Console.WriteLine("Save = Saves Log");
            accept_connection();
            string result = Console.ReadLine(); 
            if(result.ToUpper() == "STOP")
            {
                disconnect_connection();
            }
            if(result.ToUpper() == "SAVE")
            {
                save_log();
            }
            else
            {
                Console.WriteLine("Restarting Server");
                ServerStart();
            }
            

        }
        private void accept_connection()
        {
            server.BeginAcceptTcpClient(handle_connection, server);  //this is called asynchronously and will run in a different thread
        }


        private void handle_connection(IAsyncResult result)  //the parameter is a delegate, used to communicate between threads
        {
            accept_connection();  //once again, checking for any other incoming connections
            
            TcpClient client = server.EndAcceptTcpClient(result);  //creates the TcpClient
            Console.WriteLine("Incoming Connection");
            Thread.Sleep(500);
            NetworkStream ns = client.GetStream();
            if (client.Connected)
            {
                Console.WriteLine("Client Connected");
            }
            Thread.Sleep(2000);
            bClosed = true;
            Console.WriteLine("Client has Disconnected");
            bClosed = false;



        }
        private void disconnect_connection()
        {
            server.Stop();
            Console.WriteLine("Server has stopped accepting connections. Type 'Start' to restart the Server");
            string result = Console.ReadLine();
            if(result.ToUpper() == "START")
            {
                ServerStart();
            }
        }

        private void save_log()
        {
            //string tempFileName = "DETAIL_" + DateTime.Now.ToString("yyyyMMddHHmmssffff") + ".txt";
            //string tempFilePath = Environment.CurrentDirectory + "\\" + tempFileName;
            //var output = new StreamWriter(tempFilePath, false, Encoding.UTF8);
            //output.WriteLine(st));
            //output.Flush();
            //output.Close();
            //output.Dispose();
            //Console.WriteLine("====All generated====");
            //Console.ReadLine();
        }

    }

}
