﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Auth
{
    class Settings
    {
        
        public static string ip = "";
        public static int port = 2085;
        public static string ConsoleTitle = "ACSharp | Created by slushy";
        public static int Mode = 2; // (1 = Log Output, 2 = Console Output)
    
    }
}
