﻿// Atomic Installer was created on November 15th 2021
// Copyright 2021 slushy

using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Atomic_Installer.Utils;
using Atomic_Installer;
using IniParser;
using IniParser.Model;
using Newtonsoft.Json;
using System.Net;
using System.Reflection;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;
Console.Title = "Atomic Installer";
Directory.CreateDirectory("Ini");
Ini.LoadIni();
if (Ini.ReadIni("Install", "EnableConnect") == "true")
{
    ServerConnect.Connect();
    Thread.Sleep(1000);
    await Installer.InstallAtomic();
}
if (Ini.ReadIni("Install", "EnableConnect") == "false")
{
    Console.WriteLine("Atomic is in undergoing maintenance mode. Please try again later");
    Thread.Sleep(1000);
    Environment.Exit(0);
}

