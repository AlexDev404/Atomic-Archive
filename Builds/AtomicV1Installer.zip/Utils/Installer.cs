﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Atomic_Installer.Utils;
using Atomic_Installer;
using IniParser;
using IniParser.Model;
using Newtonsoft.Json;
using System.Net;
using System.Reflection;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace Atomic_Installer.Utils
{
    internal class Installer
    {
        public static async Task InstallAtomic()
        {
            Console.Clear();
            Console.WriteLine("Hello! Welcome to the Atomic Installer :). Would you like to install Atomic? This shouldn't take long. Y/N");
            string result = Console.ReadLine();
            if (result.ToUpper() == "Y")
            {
                Console.Clear();
                Console.WriteLine("Installing..");
                WebClient webClient = new WebClient();
                Directory.CreateDirectory("Atomic");
                string Temp = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Atomic";
                try
                {
                    Console.WriteLine("Installing Atom.dll");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Atom.dll", Temp + "\\Atom.dll");
                    Console.WriteLine("Installing Atomic.deps.json");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Atomic.deps.json", Temp + "\\Atomic.deps.json");
                    Console.WriteLine("Installing Atomic.dll");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Atomic.dll", Temp + "\\Atomic.dll");
                    Console.WriteLine("Installing Atomic.exe");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Atomic.exe", Temp + "\\Atomic.exe");
                    Console.WriteLine("Installing Atomic.runtimeconfig.json");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Atomic.runtimeconfig.json", Temp + "\\Atomic.runtimeconfig.json");
                    Console.WriteLine("Installing INIFileParser.dll");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/INIFileParser.dll", Temp + "\\INIFileParser.dll");
                    Console.WriteLine("Installing Newtonsoft.Json.dll");
                    await webClient.DownloadFileTaskAsync("https://api.atomicbe.ml/atomic/install/Newtonsoft.Json.dll", Temp + "\\Newtonsoft.Json.dll");
                    Console.WriteLine("Finished Installing. Closing in 3 seconds");
                    Thread.Sleep(3000);
                    Environment.Exit(0);

                }
                catch
                {
                    Directory.Delete("Atomic");
                    Console.Clear();
                    Console.WriteLine("One or more files cannot be installed");
                    Thread.Sleep(2000);
                    Environment.Exit(0);
                }
            }
            if (result.ToUpper() == "N")
            {
                Environment.Exit(0);
            }
        }
    }
}
