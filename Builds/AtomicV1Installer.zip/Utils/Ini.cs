﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IniParser;
using IniParser.Model;
using Newtonsoft.Json;
using System.Net;
using System.Reflection;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;


namespace Atomic_Installer.Utils
{
    internal class Ini
    {
        public static string HTTPGet(string url)
        {
            string result = "";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.AutomaticDecompression = DecompressionMethods.GZip;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                result = reader.ReadToEnd();
            }
            return result;
        }

        public static void LoadIni()
        {
            string Temp = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Ini";
            string a = HTTPGet("http://83.229.112.25/atomic/cloudstorage/installer.ini");
            if (!File.Exists(Temp + @"\installer.ini"))
            {
                File.WriteAllText(Temp + @"\installer.ini", a, Encoding.UTF8);
            }
            else
            {
                File.Delete(Temp + @"\installer.ini");
                File.WriteAllText(Temp + @"\installer.ini", a, Encoding.UTF8);
            }

        }

        public static string ReadIni(string section, string value)
        {
            string Temp = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Ini";
            var parser = new FileIniDataParser();
            IniData data = parser.ReadFile(Temp + @"\installer.ini");
            string Settings1 = data["Atomic." + section][value].Replace("\u0022", "");

            return Settings1;

        }


    }
    
}
