﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Installer.Utils
{
    internal class Settings
    {
        public static string srvrIP = "83.229.112.25";
        public static string srvrPort = "2085";
        public static string WebIP = "83.229.112.25";
        public static string WebPort = "80";
    }
}
