﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
//using IniParser;
//using IniParser.Model;
//using Newtonsoft.Json;
using System.Net;
using System.Reflection;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;


namespace Atomic_Installer.Utils
{
    internal class ServerConnect
    {
        public static void Connect()
        {
            // Create the socket
            //Input IP address and port
            

            // Create the socket based on date input
            Socket m_sendSocket;
            m_sendSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            //Connect to the endpoint (Server)
            // convert string IP and Port into IPAddress and int data types
            IPAddress destinationIP = IPAddress.Parse(Settings.srvrIP);
            int destinationPort = System.Convert.ToInt16(Settings.srvrPort);

            IPEndPoint destinationEP = new IPEndPoint(destinationIP, destinationPort);

            // User Message
            Console.WriteLine("\nWaiting to Connect... ");

            m_sendSocket.Connect(destinationEP);

            // User Message
            Console.WriteLine("Connected... ");
            Thread.Sleep(1000);
        }
    }
}
